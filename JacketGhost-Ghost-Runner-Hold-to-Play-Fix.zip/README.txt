JACKETGHOST GHOST RUNNER — HOLD TO PLAY (Phantom provider compatibility fix)

Upload game.html to the ROOT of the GitHub repository:
https://github.com/ngocvu12/jacketghost-site

Replace the existing game.html, commit changes, then open:
https://ngocvu12.github.io/jacketghost-site/game.html

Access rule:
- Connect Phantom on Solana mainnet.
- Reads the connected public wallet's JGHOST SPL balance.
- Minimum 1,000 JGHOST; mint: 4ZEBAApyJSc1X1sFvxmV6RcGNpaVzWExTddzoAvRucaA (6 decimals).
- No transfer, transaction, token approval, or signature is requested.
- No seed phrase/private key is collected.
- Uses Phantom's current window.phantom.solana provider with legacy window.solana fallback.

Note: uses public Solana RPC and may be rate-limited. Client-side gate is suitable for a free community mini-game, not anti-cheat/security for paid rewards. Scores remain local to the browser.
